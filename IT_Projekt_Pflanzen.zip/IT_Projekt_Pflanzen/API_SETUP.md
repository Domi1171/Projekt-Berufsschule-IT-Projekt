# API Setup

1) Upload `server_api` in deinen Webspace (z.B. Ordner `/api/`).
2) In `server_api/config.php` DB-Passwort + api_key setzen.
3) In der App: `ApiConfig.BASE_URL` auf `https://DEINE-DOMAIN.tld/api/` setzen.
4) In der App: `ApiConfig.API_KEY` gleich setzen wie in `config.php`.
