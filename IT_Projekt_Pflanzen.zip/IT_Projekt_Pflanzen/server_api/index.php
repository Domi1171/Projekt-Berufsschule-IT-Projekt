<?php
require __DIR__ . '/auth.php';
require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');
require_api_key();

$route = $_GET['route'] ?? '';
$route = trim($route, '/');

try {
    if ($route === 'messwerte/latest') {
        $sensorId = intval($_GET['sensor_id'] ?? 1);
        $stmt = db()->prepare("SELECT messwert_id, sensor_id, pflanzen_id, temperatur, feuchtigkeit, licht, gemessen_am
                               FROM messwerte
                               WHERE sensor_id = ?
                               ORDER BY gemessen_am DESC
                               LIMIT 1");
        $stmt->execute([$sensorId]);
        $row = $stmt->fetch();
        echo json_encode($row ?: new stdClass());
        exit;
    }

    if ($route === 'messwerte/history') {
        $sensorId = intval($_GET['sensor_id'] ?? 1);
        $limit = intval($_GET['limit'] ?? 50);
        if ($limit < 1) $limit = 1;
        if ($limit > 500) $limit = 500;

        $stmt = db()->prepare("SELECT messwert_id, sensor_id, pflanzen_id, temperatur, feuchtigkeit, licht, gemessen_am
                               FROM messwerte
                               WHERE sensor_id = ?
                               ORDER BY gemessen_am DESC
                               LIMIT $limit");
        $stmt->execute([$sensorId]);
        $rows = $stmt->fetchAll();
        echo json_encode($rows);
        exit;
    }

    if ($route === 'pflanzen/list') {
        $stmt = db()->query("SELECT pflanzen_id, name, beschreibung, soll_temperatur_min, soll_temperatur_max,
                                    soll_feuchtigkeit_min, soll_feuchtigkeit_max, soll_licht_min, soll_licht_max, angelegt_am
                             FROM pflanzen
                             ORDER BY angelegt_am DESC");
        echo json_encode($stmt->fetchAll());
        exit;
    }

    if ($route === 'pflanzen/create') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'method_not_allowed']);
            exit;
        }
        $body = json_decode(file_get_contents('php://input'), true);
        if (!is_array($body)) $body = [];

        $name = trim($body['name'] ?? '');
        if ($name === '') {
            http_response_code(400);
            echo json_encode(['error' => 'name_required']);
            exit;
        }

        $stmt = db()->prepare("INSERT INTO pflanzen
            (name, beschreibung, soll_temperatur_min, soll_temperatur_max, soll_feuchtigkeit_min, soll_feuchtigkeit_max, soll_licht_min, soll_licht_max)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $name,
            $body['beschreibung'] ?? null,
            $body['soll_temperatur_min'] ?? null,
            $body['soll_temperatur_max'] ?? null,
            $body['soll_feuchtigkeit_min'] ?? null,
            $body['soll_feuchtigkeit_max'] ?? null,
            $body['soll_licht_min'] ?? null,
            $body['soll_licht_max'] ?? null,
        ]);

        echo json_encode(['ok' => true, 'pflanzen_id' => intval(db()->lastInsertId())]);
        exit;
    }

    http_response_code(404);
    echo json_encode(['error' => 'not_found', 'route' => $route]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'server_error', 'message' => $e->getMessage()]);
}
