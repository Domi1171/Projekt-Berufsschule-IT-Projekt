<?php
// IONOS MySQL Zugangsdaten (bitte Passwort eintragen)
return [
    'db_host' => 'db5019198513.hosting-data.io',
    'db_port' => 3306,
    'db_name' => 'dbs15071844',
    'db_user' => 'dbu3392536',
    'db_pass' => 'HIER_DEIN_PASSWORT_EINTRAGEN',

    // API-Key Schutz (Header: X-API-KEY)
    'api_key' => 'CHANGE_ME_API_KEY',
];
