# Server API (PHP + MySQL)

Diese App nutzt Retrofit-Endpunkte wie:
- GET /messwerte/latest?sensor_id=1
- GET /messwerte/history?sensor_id=1&limit=50
- GET /pflanzen/list
- POST /pflanzen/create

## 1) Upload
Lade den Inhalt dieses Ordners `server_api` in dein Webspace-Verzeichnis (z.B. `/api/`).

Beispiel:
- https://DEINE-DOMAIN.tld/api/messwerte/latest?sensor_id=1

## 2) Datenbank-Zugang
Trage dein DB-Passwort in `config.php` ein.

Wichtig: Der MySQL-Hostname (db....hosting-data.io) ist **nicht** die HTTP-URL für Retrofit.
Retrofit braucht die URL deines Webspace/Domain, wo die PHP-Dateien liegen.

## 3) API-Key
Die App sendet einen Header `X-API-KEY`.
Setze in `config.php` einen Key und trage denselben Key in der App in `ApiConfig.kt` ein.
