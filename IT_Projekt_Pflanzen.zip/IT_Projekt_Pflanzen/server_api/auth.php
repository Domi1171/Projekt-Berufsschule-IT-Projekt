<?php
$config = require __DIR__ . '/config.php';

function require_api_key() : void {
    global $config;

    $headers = getallheaders();
    $key = $headers['X-API-KEY'] ?? $headers['x-api-key'] ?? '';

    if (!$key || $key !== $config['api_key']) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'unauthorized']);
        exit;
    }
}
