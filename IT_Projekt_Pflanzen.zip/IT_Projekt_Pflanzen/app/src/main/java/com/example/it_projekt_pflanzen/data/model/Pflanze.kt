package com.example.it_projekt_pflanzen.data.model

import com.google.gson.annotations.SerializedName

data class Pflanze(
    @SerializedName("pflanzen_id")
    val pflanzenId: Int,

    @SerializedName("name")
    val name: String,

    @SerializedName("beschreibung")
    val beschreibung: String?,

    @SerializedName("soll_temperatur_min")
    val sollTemperaturMin: Float?,

    @SerializedName("soll_temperatur_max")
    val sollTemperaturMax: Float?,

    @SerializedName("soll_feuchtigkeit_min")
    val sollFeuchtigkeitMin: Float?,

    @SerializedName("soll_feuchtigkeit_max")
    val sollFeuchtigkeitMax: Float?,

    @SerializedName("soll_licht_min")
    val sollLichtMin: Int?,

    @SerializedName("soll_licht_max")
    val sollLichtMax: Int?,

    @SerializedName("angelegt_am")
    val angelegtAm: String?
)