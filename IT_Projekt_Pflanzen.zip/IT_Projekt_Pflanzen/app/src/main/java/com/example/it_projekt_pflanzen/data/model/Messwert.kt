package com.example.it_projekt_pflanzen.data.model

import com.google.gson.annotations.SerializedName

data class Messwert(
    @SerializedName("messwert_id")
    val messwertId: Int,

    @SerializedName("sensor_id")
    val sensorId: Int,

    @SerializedName("pflanzen_id")
    val pflanzenId: Int,

    @SerializedName("temperatur")
    val temperatur: Float?,

    @SerializedName("feuchtigkeit")
    val feuchtigkeit: Float?,

    @SerializedName("bodenfeuchtigkeit")
    val bodenfeuchtigkeit: Float?,

    @SerializedName("licht")
    val licht: Int?,

    @SerializedName("gemessen_am")
    val gemessenAm: String
)