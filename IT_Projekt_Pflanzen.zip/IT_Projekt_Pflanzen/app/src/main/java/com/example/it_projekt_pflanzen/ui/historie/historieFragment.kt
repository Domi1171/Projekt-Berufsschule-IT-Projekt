package com.example.it_projekt_pflanzen.ui.historie

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.navigation.fragment.findNavController
import com.example.it_projekt_pflanzen.R
import com.example.it_projekt_pflanzen.databinding.FragmentHistorieBinding

class HistorieFragment : Fragment(R.layout.fragment_historie) {

    private var _binding: FragmentHistorieBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HistorieViewModel by viewModels()
    private lateinit var adapter: HistorieAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        _binding = FragmentHistorieBinding.bind(view)

        adapter = HistorieAdapter { item ->
            // Verlinkung: Klick öffnet Detailansicht
            val bundle = Bundle().apply { putInt("messwert_id", item.messwert_id) }
            findNavController().navigate(R.id.action_historie_to_detail, bundle)
        }
        binding.recyclerHistorie.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerHistorie.adapter = adapter


        // Filter-Spinner
        val options = resources.getStringArray(R.array.historie_filter_options).toList()
        val spinnerAdapter = android.widget.ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            options
        ).apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        binding.spinnerHistorieFilter.adapter = spinnerAdapter
        binding.spinnerHistorieFilter.setSelection(1) // Woche
        binding.spinnerHistorieFilter.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val filter = when (position) {
                    0 -> HistorieViewModel.Filter.ALL
                    1 -> HistorieViewModel.Filter.WEEK
                    2 -> HistorieViewModel.Filter.MONTH
                    3 -> HistorieViewModel.Filter.TODAY
                    else -> HistorieViewModel.Filter.WEEK
                }
                viewModel.setFilter(filter)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        viewModel.error.observe(viewLifecycleOwner) { msg ->
            binding.textHistorieError.visibility = if (msg.isNullOrBlank()) View.GONE else View.VISIBLE
            binding.textHistorieError.text = msg ?: ""
        }

        viewModel.historie.observe(viewLifecycleOwner) { liste ->
            adapter.submitList(liste ?: emptyList())
        }

        viewModel.ladeHistorie(sensorId = 1)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
