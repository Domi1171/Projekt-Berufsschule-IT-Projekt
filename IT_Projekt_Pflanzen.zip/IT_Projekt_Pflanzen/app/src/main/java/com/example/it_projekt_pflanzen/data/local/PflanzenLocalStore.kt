package com.example.it_projekt_pflanzen.data.local

import android.content.Context
import com.example.it_projekt_pflanzen.data.model.PflanzeItem
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object PflanzenLocalStore {
    private const val PREFS_NAME = "pflanzen_prefs"
    private const val KEY_LIST = "pflanzen_list_json"
    private val gson = Gson()

    fun load(context: Context): MutableList<PflanzeItem> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_LIST, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<PflanzeItem>>() {}.type
            gson.fromJson<MutableList<PflanzeItem>>(json, type) ?: mutableListOf()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, list: List<PflanzeItem>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LIST, gson.toJson(list)).apply()
    }
}
