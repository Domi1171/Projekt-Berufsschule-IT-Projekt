package com.example.it_projekt_pflanzen.ui.pflanzen_info

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.it_projekt_pflanzen.R
import com.example.it_projekt_pflanzen.databinding.FragmentPflanzenInfoBinding
import com.example.it_projekt_pflanzen.data.model.PflanzeItem

class PflanzenInfoFragment : Fragment() {

    private var _binding: FragmentPflanzenInfoBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: PflanzenAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val viewModel = ViewModelProvider(this)[PflanzenInfoViewModel::class.java]

        viewModel.loadOnce(requireContext())

        // Ergebnis aus "Neue Pflanze" empfangen
        findNavController().currentBackStackEntry
            ?.savedStateHandle
            ?.getLiveData<PflanzeItem>("new_pflanze")
            ?.observe(viewLifecycleOwner) { newItem ->
                viewModel.addLocal(requireContext(), newItem)
                findNavController().currentBackStackEntry?.savedStateHandle?.remove<PflanzeItem>("new_pflanze")
            }

        _binding = FragmentPflanzenInfoBinding.inflate(inflater, container, false)
        val root: View = binding.root

        adapter = PflanzenAdapter { pflanze ->
            val b = Bundle().apply {
                putString(PflanzeDetailFragment.ARG_NAME, pflanze.name)
                putString(PflanzeDetailFragment.ARG_BESCHREIBUNG, pflanze.beschreibung)
                putString(PflanzeDetailFragment.ARG_BILD_URI, pflanze.bildUri)

                putFloat(PflanzeDetailFragment.ARG_TEMP_MIN, pflanze.sollTemperaturMin ?: Float.NaN)
                putFloat(PflanzeDetailFragment.ARG_TEMP_MAX, pflanze.sollTemperaturMax ?: Float.NaN)
                putFloat(PflanzeDetailFragment.ARG_FEUCHTE_MIN, pflanze.sollFeuchtigkeitMin ?: Float.NaN)
                putFloat(PflanzeDetailFragment.ARG_FEUCHTE_MAX, pflanze.sollFeuchtigkeitMax ?: Float.NaN)
                putInt(PflanzeDetailFragment.ARG_LICHT_MIN, pflanze.sollLichtMin ?: Int.MIN_VALUE)
                putInt(PflanzeDetailFragment.ARG_LICHT_MAX, pflanze.sollLichtMax ?: Int.MIN_VALUE)
            }
            findNavController().navigate(R.id.action_pflanzen_info_to_detail, b)
        }

        binding.recyclerPflanzen.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerPflanzen.adapter = adapter

        viewModel.pflanzen.observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
        }

        // „Anlage neuer Pflanzen“ über Button (Verlinkung)
        binding.buttonNeuePflanze.setOnClickListener {
            findNavController().navigate(R.id.action_pflanzen_info_to_neu)
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
