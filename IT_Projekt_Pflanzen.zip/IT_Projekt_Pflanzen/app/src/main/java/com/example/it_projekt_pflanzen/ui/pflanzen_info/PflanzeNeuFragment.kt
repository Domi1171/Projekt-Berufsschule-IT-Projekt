package com.example.it_projekt_pflanzen.ui.pflanzen_info

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.it_projekt_pflanzen.databinding.FragmentPflanzeNeuBinding
import com.example.it_projekt_pflanzen.data.model.PflanzeItem

class PflanzeNeuFragment : Fragment() {

    private var _binding: FragmentPflanzeNeuBinding? = null
    private val binding get() = _binding!!

    private var selectedImageUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedImageUri = uri
        if (uri != null) {
            binding.imagePreview.setImageURI(uri)
            binding.textStatus.text = "Bild ausgewählt"
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPflanzeNeuBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Bild auswählen (optional)
        binding.buttonBildAuswaehlen.setOnClickListener {
            pickImage.launch("image/*")
        }

        // Struktur: Formular – Logik/POST folgt später
        binding.buttonSpeichern.setOnClickListener {
            val name = binding.editName.text?.toString()?.trim().orEmpty()
            val beschreibung = binding.editBeschreibung.text?.toString()?.trim().orEmpty()

            val tempMin = binding.editTempMin.text?.toString()?.toFloatOrNull()
            val tempMax = binding.editTempMax.text?.toString()?.toFloatOrNull()
            val feuchteMin = binding.editFeuchteMin.text?.toString()?.toFloatOrNull()
            val feuchteMax = binding.editFeuchteMax.text?.toString()?.toFloatOrNull()
            val lichtMin = binding.editLichtMin.text?.toString()?.toIntOrNull()
            val lichtMax = binding.editLichtMax.text?.toString()?.toIntOrNull()

            val img = selectedImageUri?.toString() ?: "(kein Bild)"

            val item = PflanzeItem(
                pflanzen_id = 0, // wird lokal im ViewModel vergeben
                name = name,
                beschreibung = beschreibung,
                sollTemperaturMin = tempMin,
                sollTemperaturMax = tempMax,
                sollFeuchtigkeitMin = feuchteMin,
                sollFeuchtigkeitMax = feuchteMax,
                sollLichtMin = lichtMin,
                sollLichtMax = lichtMax,
                bildUri = selectedImageUri?.toString()
            )

            // zurück an PflanzenInfo geben
            findNavController().previousBackStackEntry
                ?.savedStateHandle
                ?.set("new_pflanze", item)

            // zurück zur Liste
            findNavController().popBackStack()
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
