package com.example.it_projekt_pflanzen.ui.pflanzen_info

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.it_projekt_pflanzen.data.model.PflanzeItem
import com.example.it_projekt_pflanzen.databinding.ItemPflanzeBinding

class PflanzenAdapter(
    private val onClick: (PflanzeItem) -> Unit
) : ListAdapter<PflanzeItem, PflanzenAdapter.ViewHolder>(DIFF) {

    class ViewHolder(
        private val binding: ItemPflanzeBinding,
        private val onClick: (PflanzeItem) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: PflanzeItem) {
            binding.textName.text = item.name
            binding.textKurz.text = item.beschreibung
            binding.root.setOnClickListener { onClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPflanzeBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding, onClick)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<PflanzeItem>() {
            override fun areItemsTheSame(oldItem: PflanzeItem, newItem: PflanzeItem): Boolean =
                oldItem.pflanzen_id == newItem.pflanzen_id

            override fun areContentsTheSame(oldItem: PflanzeItem, newItem: PflanzeItem): Boolean =
                oldItem == newItem
        }
    }
}
