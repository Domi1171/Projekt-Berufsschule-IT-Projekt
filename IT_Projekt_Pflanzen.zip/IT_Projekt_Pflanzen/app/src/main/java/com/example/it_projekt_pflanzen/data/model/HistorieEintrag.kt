package com.example.it_projekt_pflanzen.data.model

data class HistorieEintrag(
    val messwert_id: Int,
    val temperatur: Float?,
    val feuchtigkeit: Float?,
    val bodenfeuchtigkeit: Float?,
    val licht: Int?,
    val gemessen_am: String?
)
