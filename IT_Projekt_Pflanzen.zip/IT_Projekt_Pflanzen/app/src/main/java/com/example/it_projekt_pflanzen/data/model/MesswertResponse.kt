package com.example.it_projekt_pflanzen.data.model

/**
 * Antwortmodell für den Endpoint `messwerte/latest`.
 *
 * Die Server-API liefert direkt ein Objekt mit den DB-Spalten (oder `{}` wenn leer).
 * Daher sind alle Felder nullable.
 */
data class MesswertResponse(
    val messwert_id: Int? = null,
    val sensor_id: Int? = null,
    val pflanzen_id: Int? = null,
    val temperatur: Float? = null,
    val feuchtigkeit: Float? = null,
    val licht: Int? = null,
    val gemessen_am: String? = null
)
