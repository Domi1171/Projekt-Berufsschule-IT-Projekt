package com.example.it_projekt_pflanzen.ui.pflanzen_info

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.it_projekt_pflanzen.data.local.PflanzenLocalStore
import com.example.it_projekt_pflanzen.data.model.PflanzeItem

class PflanzenInfoViewModel : ViewModel() {

    private val _pflanzen = MutableLiveData<List<PflanzeItem>>(emptyList())
    val pflanzen: LiveData<List<PflanzeItem>> = _pflanzen

    private var initialized = false

    /**
     * Lädt die Pflanzen aus SharedPreferences.
     * Wenn noch nichts gespeichert ist, werden Demo-Pflanzen initial gesetzt und gespeichert.
     */
    fun loadOnce(context: Context) {
        if (initialized) return
        initialized = true

        val stored = PflanzenLocalStore.load(context)
        if (stored.isNotEmpty()) {
            _pflanzen.value = stored
            return
        }

        val demo = mutableListOf(
            PflanzeItem(
                pflanzen_id = 1,
                name = "Monstera",
                beschreibung = "Helles, indirektes Licht. Gleichmäßig feucht halten.",
                sollTemperaturMin = 18f,
                sollTemperaturMax = 26f,
                sollFeuchtigkeitMin = 40f,
                sollFeuchtigkeitMax = 70f,
                sollLichtMin = 300,
                sollLichtMax = 1500
            ),
            PflanzeItem(
                pflanzen_id = 2,
                name = "Kaktus",
                beschreibung = "Viel Sonne, wenig Wasser.",
                sollTemperaturMin = 16f,
                sollTemperaturMax = 32f,
                sollFeuchtigkeitMin = 20f,
                sollFeuchtigkeitMax = 50f,
                sollLichtMin = 800,
                sollLichtMax = 5000
            )
        )

        _pflanzen.value = demo
        PflanzenLocalStore.save(context, demo)
    }

    fun addLocal(context: Context, item: PflanzeItem) {
        val current = (_pflanzen.value ?: emptyList()).toMutableList()
        val nextId = (current.maxOfOrNull { it.pflanzen_id } ?: 0) + 1

        val toAdd = item.copy(pflanzen_id = nextId)
        current.add(0, toAdd)

        _pflanzen.value = current
        PflanzenLocalStore.save(context, current)
    }
}
