package com.example.it_projekt_pflanzen.data.api

import com.example.it_projekt_pflanzen.data.model.HistorieEintrag
import com.example.it_projekt_pflanzen.data.model.Messwert
import com.example.it_projekt_pflanzen.data.model.Pflanze

class MesswertRepository {

    private val api = ApiClient.pflanzenApi

    /**
     * Neuesten Messwert abrufen
     * Aufruf: repo.getLatest(sensorId = 1)
     */
    suspend fun getLatest(sensorId: Int = 1): Messwert {
        val response = api.getLatestMesswert(sensorId)
        if (response.status == "success" && response.data != null) {
            return response.data
        }
        throw Exception("Keine Messwerte gefunden")
    }

    /**
     * Historie abrufen (für Charts und Historie-Screen)
     * Aufruf: repo.getHistory(sensorId = 1)
     */
    suspend fun getHistory(sensorId: Int = 1, limit: Int = 200): List<HistorieEintrag> {
        val response = api.getMesswerte(pflanzenId = sensorId, limit = limit)
        if (response.status == "success") {
            return response.data.map { m ->
                HistorieEintrag(
                    messwert_id = m.messwertId,
                    temperatur = m.temperatur,
                    feuchtigkeit = m.feuchtigkeit,
                    bodenfeuchtigkeit = m.bodenfeuchtigkeit,
                    licht = m.licht,
                    gemessen_am = m.gemessenAm
                )
            }
        }
        throw Exception("Fehler beim Laden der Historie")
    }

    /**
     * Alle Pflanzen abrufen
     */
    suspend fun getPflanzen(): List<Pflanze> {
        val response = api.getPflanzen()
        if (response.status == "success") {
            return response.data
        }
        throw Exception("Fehler beim Laden der Pflanzen")
    }

    /**
     * Eine bestimmte Pflanze abrufen
     */
    suspend fun getPflanze(pflanzenId: Int): Pflanze {
        val response = api.getPflanze(pflanzenId)
        if (response.status == "success" && response.data != null) {
            return response.data
        }
        throw Exception("Pflanze nicht gefunden")
    }
}
