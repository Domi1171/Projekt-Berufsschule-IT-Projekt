package com.example.it_projekt_pflanzen.data.model

/**
 * Antwort-Wrapper für Listen (messwerte, pflanzen)
 * Entspricht dem PHP-JSON: {"status":"success","count":5,"data":[...]}
 */
data class ApiResponse<T>(
    val status: String,
    val count: Int?,
    val data: List<T>
)

/**
 * Antwort-Wrapper für einzelne Objekte (latest, pflanze)
 * Entspricht dem PHP-JSON: {"status":"success","data":{...}}
 */
data class SingleApiResponse<T>(
    val status: String,
    val data: T?
)