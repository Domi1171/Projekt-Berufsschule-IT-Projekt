package com.example.it_projekt_pflanzen.ui.historie

import androidx.lifecycle.*
import com.example.it_projekt_pflanzen.data.api.MesswertRepository
import com.example.it_projekt_pflanzen.data.model.HistorieEintrag
import kotlinx.coroutines.launch
import java.time.*
import java.time.format.DateTimeFormatter

class HistorieViewModel : ViewModel() {

    enum class Filter { ALL, TODAY, WEEK, MONTH }

    private val repository = MesswertRepository()

    private val _all = MutableLiveData<List<HistorieEintrag>>(emptyList())
    private val _filter = MutableLiveData(Filter.WEEK)

    private val _error = MutableLiveData<String?>(null)
    val error: LiveData<String?> = _error

    val historie: LiveData<List<HistorieEintrag>> = MediatorLiveData<List<HistorieEintrag>>().apply {
        fun recompute() {
            val list = _all.value ?: emptyList()
            val f = _filter.value ?: Filter.WEEK
            value = filterList(list, f)
        }
        addSource(_all) { recompute() }
        addSource(_filter) { recompute() }
    }

    fun setFilter(filter: Filter) {
        _filter.value = filter
    }

    fun ladeHistorie(sensorId: Int) {
        viewModelScope.launch {
            try {
                _error.value = null
                _all.value = repository.getHistory(sensorId)
            } catch (e: Exception) {
                _all.value = emptyList()
                _error.value = e.message ?: "Fehler beim Laden der Historie"
            }
        }
    }

    private fun filterList(list: List<HistorieEintrag>, filter: Filter): List<HistorieEintrag> {
        if (filter == Filter.ALL) return list
        val now = LocalDateTime.now()
        val cutoff = when (filter) {
            Filter.TODAY -> now.toLocalDate().atStartOfDay()
            Filter.WEEK -> now.minusDays(7)
            Filter.MONTH -> now.minusDays(30)
            else -> now.minusDays(7)
        }
        return list.filter { item ->
            val t = parseDate(item.gemessen_am)
            t == null || !t.isBefore(cutoff)
        }
    }

    private fun parseDate(raw: String?): LocalDateTime? {
        if (raw.isNullOrBlank()) return null
        // Try ISO formats first
        try {
            return Instant.parse(raw).atZone(ZoneId.systemDefault()).toLocalDateTime()
        } catch (_: Exception) {}
        // common MySQL: "yyyy-MM-dd HH:mm:ss"
        val patterns = listOf(
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss.SSS"
        )
        for (p in patterns) {
            try {
                val fmt = DateTimeFormatter.ofPattern(p)
                return LocalDateTime.parse(raw, fmt)
            } catch (_: Exception) {}
        }
        return null
    }
}
