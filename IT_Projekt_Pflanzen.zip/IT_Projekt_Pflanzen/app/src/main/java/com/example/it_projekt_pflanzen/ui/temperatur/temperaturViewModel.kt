package com.example.it_projekt_pflanzen.ui.temperatur

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.it_projekt_pflanzen.data.api.MesswertRepository
import kotlinx.coroutines.launch

class TemperaturViewModel : ViewModel() {

    private val repository = MesswertRepository()

    private val _text = MutableLiveData<String>().apply {
        value = "Lade Daten..."
    }
    val text: LiveData<String> = _text

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            try {
                val latest = repository.getLatest(sensorId = 1)
                val history = repository.getHistory(sensorId = 1, limit = 20)

                val sb = StringBuilder()
                sb.appendLine("🌡 Aktuelle Temperatur")
                sb.appendLine("${latest.temperatur ?: "-"} °C")
                sb.appendLine()
                sb.appendLine("📊 Letzte ${history.size} Messungen:")
                sb.appendLine()
                history.takeLast(10).forEach { entry ->
                    sb.appendLine("${entry.gemessen_am}  →  ${entry.temperatur ?: "-"} °C")
                }

                _text.value = sb.toString()
            } catch (e: Exception) {
                _text.value = "Fehler: ${e.message}"
            }
        }
    }
}
