package com.example.it_projekt_pflanzen.ui.licht

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.it_projekt_pflanzen.data.api.MesswertRepository
import kotlinx.coroutines.launch

class lichtViewModel : ViewModel() {

    private val repository = MesswertRepository()

    private val _text = MutableLiveData<String>().apply {
        value = "Lade Daten..."
    }
    val text: LiveData<String> = _text

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            try {
                val latest = repository.getLatest(sensorId = 1)
                val history = repository.getHistory(sensorId = 1, limit = 20)

                val sb = StringBuilder()
                sb.appendLine("💡 Aktueller Lichtwert")
                sb.appendLine("${latest.licht ?: "-"} lx")
                sb.appendLine()
                sb.appendLine("📊 Letzte ${history.size} Messungen:")
                sb.appendLine()
                history.takeLast(10).forEach { entry ->
                    sb.appendLine("${entry.gemessen_am}  →  ${entry.licht ?: "-"} lx")
                }

                _text.value = sb.toString()
            } catch (e: Exception) {
                _text.value = "Fehler: ${e.message}"
            }
        }
    }
}
