package com.example.it_projekt_pflanzen.data.api

import com.example.it_projekt_pflanzen.data.model.ApiResponse
import com.example.it_projekt_pflanzen.data.model.Messwert
import com.example.it_projekt_pflanzen.data.model.Pflanze
import com.example.it_projekt_pflanzen.data.model.SingleApiResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface PflanzenApi {

    // Letzte Messwerte abrufen (Standard: 50)
    @GET("api.php?action=messwerte")
    suspend fun getMesswerte(
        @Query("pflanzen_id") pflanzenId: Int? = null,
        @Query("limit") limit: Int? = null
    ): ApiResponse<Messwert>

    // Nur den neuesten Messwert einer Pflanze
    @GET("api.php?action=latest")
    suspend fun getLatestMesswert(
        @Query("pflanzen_id") pflanzenId: Int = 1
    ): SingleApiResponse<Messwert>

    // Alle Pflanzen abrufen
    @GET("api.php?action=pflanzen")
    suspend fun getPflanzen(): ApiResponse<Pflanze>

    // Eine bestimmte Pflanze abrufen
    @GET("api.php?action=pflanze")
    suspend fun getPflanze(
        @Query("pflanzen_id") pflanzenId: Int
    ): SingleApiResponse<Pflanze>
}