package com.example.it_projekt_pflanzen.ui.pflanzen_info

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.it_projekt_pflanzen.databinding.FragmentPflanzeDetailBinding

class PflanzeDetailFragment : Fragment() {

    private var _binding: FragmentPflanzeDetailBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPflanzeDetailBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val args = arguments
        val name = args?.getString(ARG_NAME).orEmpty()
        val beschreibung = args?.getString(ARG_BESCHREIBUNG).orEmpty()
        val bildUri = args?.getString(ARG_BILD_URI)

        val tempMin = args?.getFloat(ARG_TEMP_MIN, Float.NaN)
        val tempMax = args?.getFloat(ARG_TEMP_MAX, Float.NaN)
        val feuchteMin = args?.getFloat(ARG_FEUCHTE_MIN, Float.NaN)
        val feuchteMax = args?.getFloat(ARG_FEUCHTE_MAX, Float.NaN)
        val lichtMin = args?.getInt(ARG_LICHT_MIN, Int.MIN_VALUE)
        val lichtMax = args?.getInt(ARG_LICHT_MAX, Int.MIN_VALUE)

        binding.textName.text = name
        binding.textBeschreibung.text = beschreibung

        if (!bildUri.isNullOrBlank()) {
            binding.imagePreview.setImageURI(Uri.parse(bildUri))
        }

        val tempStr = if (tempMin != null && tempMax != null && !tempMin.isNaN() && !tempMax.isNaN()) "$tempMin-$tempMax °C" else "-"
        val feuchteStr = if (feuchteMin != null && feuchteMax != null && !feuchteMin.isNaN() && !feuchteMax.isNaN()) "$feuchteMin-$feuchteMax %" else "-"
        val lichtStr = if (lichtMin != null && lichtMax != null && lichtMin != Int.MIN_VALUE && lichtMax != Int.MIN_VALUE) "$lichtMin-$lichtMax Lux" else "-"

        binding.textSollwerteDetails.text = "Temp: $tempStr | Feuchte: $feuchteStr | Licht: $lichtStr"

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val ARG_NAME = "arg_name"
        const val ARG_BESCHREIBUNG = "arg_beschreibung"
        const val ARG_BILD_URI = "arg_bild_uri"

        const val ARG_TEMP_MIN = "arg_temp_min"
        const val ARG_TEMP_MAX = "arg_temp_max"
        const val ARG_FEUCHTE_MIN = "arg_feuchte_min"
        const val ARG_FEUCHTE_MAX = "arg_feuchte_max"
        const val ARG_LICHT_MIN = "arg_licht_min"
        const val ARG_LICHT_MAX = "arg_licht_max"
    }
}
