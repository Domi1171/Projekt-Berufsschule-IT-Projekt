package com.example.it_projekt_pflanzen.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import com.example.it_projekt_pflanzen.databinding.FragmentHomeBinding
import com.example.it_projekt_pflanzen.data.api.MesswertRepository
import com.example.it_projekt_pflanzen.ui.pflanzen_info.PflanzenInfoViewModel
import androidx.lifecycle.ViewModelProvider

import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        // hier wird der Text für den Anfang gesetzt
        binding.tvWelcome.text = "Herzlich Willkommen 👋"
        binding.tvStatus.text = "Alle Sensoren aktiv"

        // Quick Actions
        binding.btnQuickNeuePflanze.setOnClickListener {
            findNavController().navigate(com.example.it_projekt_pflanzen.R.id.nav_pflanzen_neu)
        }
        binding.btnQuickHistorie.setOnClickListener {
            findNavController().navigate(com.example.it_projekt_pflanzen.R.id.nav_historie)
        }
        binding.btnQuickTemperatur.setOnClickListener {
            findNavController().navigate(com.example.it_projekt_pflanzen.R.id.nav_temperatur)
        }

        // Daten laden (letzte Messung + Pflanzenanzahl) + Warnlogik
        val repo = MesswertRepository()
        val plantsVm = ViewModelProvider(requireActivity())[PflanzenInfoViewModel::class.java]

        plantsVm.pflanzen.observe(viewLifecycleOwner) { list ->
            binding.tvCardPlants.text = "🌱 Pflanzen\n${list.size}"
        }

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val latest = repo.getLatest(sensorId = 1)
                val t = latest.temperatur?.toString() ?: "-"
                val h = latest.feuchtigkeit?.toString() ?: "-"
                val l = latest.licht?.toString() ?: "-"

                binding.tvCardTemp.text = "🌡 Temperatur\n$t °C"
                binding.tvCardHum.text = "💧 Luftfeuchte\n$h %"
                binding.tvCardLight.text = "💡 Licht\n$l lx"


                // Diagramm: letzte Messwerte (max 20)
                try {
                    val hist = repo.getHistory(sensorId = 1)
                    val last = hist.takeLast(20)
                    renderChart(
                        temp = last.map { it.temperatur },
                        hum = last.map { it.feuchtigkeit }
                    )
                } catch (_: Exception) {
                    // Chart bleibt leer, aber App läuft
                }

                // Warnlogik anhand erster Pflanze (falls Sollwerte gesetzt)
                val first = plantsVm.pflanzen.value?.firstOrNull()
                val warnings = mutableListOf<String>()
                if (first != null) {
                    latest.temperatur?.let { temp ->
                        first.sollTemperaturMin?.let { if (temp < it) warnings.add("Temperatur zu niedrig") }
                        first.sollTemperaturMax?.let { if (temp > it) warnings.add("Temperatur zu hoch") }
                    }
                    latest.feuchtigkeit?.let { feucht ->
                        first.sollFeuchtigkeitMin?.let { if (feucht < it) warnings.add("Feuchtigkeit zu niedrig") }
                        first.sollFeuchtigkeitMax?.let { if (feucht > it) warnings.add("Feuchtigkeit zu hoch") }
                    }
                    latest.licht?.let { licht ->
                        first.sollLichtMin?.let { if (licht < it) warnings.add("Licht zu niedrig") }
                        first.sollLichtMax?.let { if (licht > it) warnings.add("Licht zu hoch") }
                    }
                }

                if (warnings.isNotEmpty()) {
                    binding.cardWarnung.visibility = View.VISIBLE
                    binding.tvWarnung.text = "⚠ " + warnings.joinToString(" • ")
                    binding.tvStatus.text = "Achtung: Abweichung erkannt"
                } else {
                    binding.cardWarnung.visibility = View.GONE
                }

            } catch (e: Exception) {
                // offline / API down: kein Crash, nur Info
                binding.tvStatus.text = "Offline: Keine Live-Daten"
            }
        }


        return binding.root
    }

    private fun renderChart(temp: List<Float?>, hum: List<Float?>) {
        try {
            val entriesTemp = temp.mapIndexedNotNull { i, v -> v?.let { Entry(i.toFloat(), it) } }
            val entriesHum = hum.mapIndexedNotNull { i, v -> v?.let { Entry(i.toFloat(), it) } }

            val dsTemp = LineDataSet(entriesTemp, "Temperatur")
            val dsHum = LineDataSet(entriesHum, "Feuchtigkeit")

            val lineData = LineData(dsTemp, dsHum)
            binding.homeLineChart.data = lineData
            binding.homeLineChart.description.isEnabled = false
            binding.homeLineChart.invalidate()
        } catch (_: Exception) {
            // Chart optional – keine App-Abstürze
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
