package com.example.it_projekt_pflanzen.data.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class PflanzeItem(
    @SerializedName("pflanzen_id")
    val pflanzen_id: Int,
    val name: String,
    @SerializedName("beschreibung")
    val beschreibung: String,
    @SerializedName("soll_temperatur_min")
    val sollTemperaturMin: Float? = null,
    @SerializedName("soll_temperatur_max")
    val sollTemperaturMax: Float? = null,
    @SerializedName("soll_feuchtigkeit_min")
    val sollFeuchtigkeitMin: Float? = null,
    @SerializedName("soll_feuchtigkeit_max")
    val sollFeuchtigkeitMax: Float? = null,
    @SerializedName("soll_licht_min")
    val sollLichtMin: Int? = null,
    @SerializedName("soll_licht_max")
    val sollLichtMax: Int? = null,
    @SerializedName("bild_uri")
    val bildUri: String? = null

) : Serializable
