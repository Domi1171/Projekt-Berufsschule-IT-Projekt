package com.example.it_projekt_pflanzen.ui.historie

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.it_projekt_pflanzen.databinding.FragmentHistorieDetailBinding

class HistorieDetailFragment : Fragment() {

    private var _binding: FragmentHistorieDetailBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistorieDetailBinding.inflate(inflater, container, false)
        val root = binding.root

        val id = arguments?.getInt("messwert_id") ?: -1
        binding.textDetail.text = "Historie-Detail für Messwert-ID: $id\n(Platzhalter – Details/API folgen später)"

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
