package com.example.it_projekt_pflanzen.data.api

object ApiConfig {
    const val BASE_URL = "http://www.elbawohnmobile.de/"
}