package com.example.it_projekt_pflanzen.data.model

import com.google.gson.annotations.SerializedName

/**
 * Typische Antwort vom Backend nach dem Anlegen einer Pflanze.
 * Falls dein PHP/Backend andere Keys nutzt, kann Gson das über @SerializedName mappen.
 */
data class PflanzeCreateResponse(
    @SerializedName("ok")
    val ok: Boolean = false,

    @SerializedName("pflanzen_id")
    val pflanzenId: Int? = null,

    @SerializedName("message")
    val message: String? = null
)
