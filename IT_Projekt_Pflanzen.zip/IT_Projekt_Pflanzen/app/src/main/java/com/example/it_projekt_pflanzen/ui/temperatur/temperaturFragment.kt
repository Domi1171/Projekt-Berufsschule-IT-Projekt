package com.example.it_projekt_pflanzen.ui.temperatur

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.it_projekt_pflanzen.databinding.FragmentTemperaturBinding

class TemperaturFragment : Fragment() {

    private var _binding: FragmentTemperaturBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val temperaturViewModel =
            ViewModelProvider(this).get(TemperaturViewModel::class.java)

        _binding = FragmentTemperaturBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textTemperatur
        temperaturViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
