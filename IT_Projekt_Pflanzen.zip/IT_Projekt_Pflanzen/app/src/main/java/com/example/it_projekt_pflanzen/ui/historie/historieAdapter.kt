package com.example.it_projekt_pflanzen.ui.historie

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.it_projekt_pflanzen.data.model.HistorieEintrag
import com.example.it_projekt_pflanzen.databinding.ItemHistorieBinding

class HistorieAdapter(
    private val onItemClick: ((HistorieEintrag) -> Unit)? = null
) : ListAdapter<HistorieEintrag, HistorieAdapter.ViewHolder>(DIFF_CALLBACK) {

    class ViewHolder(private val binding: ItemHistorieBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: HistorieEintrag, onItemClick: ((HistorieEintrag) -> Unit)?) {
            binding.textTemperatur.text = item.temperatur?.toString() ?: "-"
            binding.textFeuchtigkeit.text = item.feuchtigkeit?.toString() ?: "-"
            binding.textLicht.text = item.licht?.toString() ?: "-"
            binding.textZeitpunkt.text = item.gemessen_am ?: "-"
            binding.root.setOnClickListener { onItemClick?.invoke(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistorieBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), onItemClick)
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<HistorieEintrag>() {
            override fun areItemsTheSame(oldItem: HistorieEintrag, newItem: HistorieEintrag): Boolean {
                return oldItem.messwert_id == newItem.messwert_id
            }

            override fun areContentsTheSame(oldItem: HistorieEintrag, newItem: HistorieEintrag): Boolean {
                return oldItem == newItem
            }
        }
    }
}
