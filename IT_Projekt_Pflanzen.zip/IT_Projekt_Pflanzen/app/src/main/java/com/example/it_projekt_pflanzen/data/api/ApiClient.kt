package com.example.it_projekt_pflanzen.data.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(ApiConfig.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val pflanzenApi: PflanzenApi by lazy {
        retrofit.create(PflanzenApi::class.java)
    }
}